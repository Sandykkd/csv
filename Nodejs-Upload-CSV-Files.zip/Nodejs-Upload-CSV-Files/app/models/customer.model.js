module.exports = (sequelize, Sequelize) => {
  sequelize.sync({
    force: true
  });
          // your code 
  
  const Customer = sequelize.define("customer", {
    uid: {
      type: Sequelize.INTEGER,
      primaryKey: true
    },
    name: {
      type: Sequelize.STRING,
    },
    email: {
      type: Sequelize.STRING,
    },
    gender: {
      type: Sequelize.STRING,
    },
    designation: {
      type: Sequelize.STRING,
    },
    dept: {
      type: Sequelize.STRING,
    },
    mobile: {
      type: Sequelize.INTEGER,
	},
	photo: {
		type: Sequelize.STRING
  }
  });

  return Customer;
  //});
};
